// Global mutable state
window.App = {
    usersWithToken: [],
    usernameMap: {},
    allEventData: [],
    playerResults: null,
    opponentMatchHistory: {},
    selectedPlayerId: null,
    acHighlight: -1,
    selectedStore: null,
    regionalsOnly: false,
    charts: {},
    rankStore: null,
    rankDatePreset: 'all',
    rankRegionalsOnly: false,
    podiumSort: 'pct',
    lastLeaderboardUsers: null,
    storeH2HUsers: [],
    competitiveBadges: null,   // { reiDosPiratas: {year: {bandaiId,name,winRate}}, yonkou: [], shichibukai: [], month }
    profileDirectory: {},      // { 'bandainame_lower' → publicProfile }
};
const CACHE_PREFIX = 'bandai_events_';
